        
# *** Spyder Python Console History Log ***
        id150 = np.argmin(dists)
        if np.sum(id0125):
            print coordonnees
            vmean = np.nanmean(matr[id0125,:], axis=0)
            vmin = np.nanmin(matr[id0125,:], axis=0)
            vmax = np.nanmax(matr[id0125,:], axis=0)
            vstd = np.nanstd(matr[id0125,:], axis=0)
            flag = 0.
        elif dists[id150] <= 1.5:
            vmean = matr[id150,:]
            vmin = matr[id150,:]
            vmax = matr[id150,:]
            vstd = matr[id150,:]
            flag = 0.
        else:
            
            vmean = vmax = vmin = vstd = np.asarray([np.nan]*4)
            flag = -9999
    else:
        vmean = vmax = vmin = vstd = np.asarray([np.nan]*4)
        flag = -9999
    return np.hstack([vmean, vmin, vmax, vstd, flag])

appIn(np.vstack([calcStat(coord, datas, lon, lat) for coord in xy]))
coordonnees = (-0.75, 35.75)
matr = datas
longitude=lon
latitude=lat
x_px = coordonnees[0]
y_px = coordonnees[1]
dists = np.sqrt((longitude[:]-x_px)**2 + (latitude[:]-y_px)**2)
dists
dists.size
id0125 = dists <= 0.125
np.sum(id0125)
id150 = np.argmin(dists)
id150
dists.shape
matr.shape
id0125
matr[id0125]
np.where(id0125)
matr[317,...]
dists[317]
dists[318]
dists[319]
dists[316]
id150
vmean = np.nanmean(matr[id0125,:], axis=0)
vmin = np.nanmin(matr[id0125,:], axis=0)
vmax = np.nanmax(matr[id0125,:], axis=0)
vstd = np.nanstd(matr[id0125,:], axis=0)
vmean
nc.variables.keys()
Base = nc.variables['dust_Base_mean'][0,...]
Base.shape
nclon = nc.variables['longitude'][:]
nclat=nc.variables['latitude'][:]
np.where((nclon=-0.75))
np.where((nclon==-0.75))
np.where((nclat==-35.75))
np.where((nclat==35.75))
Base[61,97]
Top = nc.variable['dust_Top_mean'][0,...]
Top = nc.variables['dust_Top_mean'][0,...]
Top[61,97]
from datetime importdatetime
from datetime import datetime
datetime.now()
str(datetime.now())
str(datetime.now().date())
print("log %s" %(datetime.now()))

##---(Wed Feb 15 17:18:05 2017)---
import grass.script as gr
import grass.lib

##---(Wed Feb 15 17:27:50 2017)---
import grass.script as gr

##---(Wed Feb 15 17:40:47 2017)---
import grass.script as gr

##---(Wed Feb 15 17:50:50 2017)---
import grass.script as gr
import grass
grass
grass.__version__
import gdal
import grass.script as gr
import os, sys
gisbase = os.environ['GISBASE'] = '/home/mers/.local/bin/grass'
gisrc='/home/mers/.local/bin/grass'
gisbase='home/mers/grassdata'
for k in sorted(os.environ.keys()): print '\n\n' + k + os.environ[k] + '\n'
for k in sorted(os.environ.keys()): print '\n\n' + k + os.environ[k]
for k in sorted(os.environ.keys()): print '\n' + k + os.environ[k] + '\n'
for k in sorted(os.environ.keys()): print '\n' + k + '\n' + os.environ[k] + '\n'
for k in sorted(os.environ.keys()): print k + '\n' + os.environ[k] + '\n'

##---(Wed Feb 15 18:07:24 2017)---
import os
for k in sorted(os.environ.keys()): print k + '\n' + os.environ[k] + '\n'
import grass.script as gr
import pygrass

##---(Thu Feb 16 09:30:28 2017)---
import grass.script

##---(Fri Feb 24 17:39:52 2017)---
import grass.script as grass

##---(Fri Feb 24 17:41:05 2017)---
import grass.script as grass